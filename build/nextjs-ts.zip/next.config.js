import withCloud from "@serverless/cloud/nextjs";

export default withCloud({
  reactStrictMode: true,
});

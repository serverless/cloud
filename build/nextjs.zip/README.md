# Getting started

First start your developer sandbox:

```
npm install
cloud dev
```

Visit the dev site at http://localhost:3000

# Deploying

In the cloud shell type `deploy production` to build and deploy an instance named production.
